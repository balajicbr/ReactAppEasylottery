import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './MyWins.css';
// import UpdateKycModal from '../components/UpdateKycModal';

const MyWins = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [showKycModal, setShowKycModal] = useState(false);

  const handleBack = () => {
    navigate(-1);
  };

  const handleClaimPrize = (ticketId) => {
    console.log('Claiming prize for ticket:', ticketId);
    // Navigate to claim prize page
    navigate('/claim-prize');
  };

  const handleCloseKycModal = () => {
    setShowKycModal(false);
  };

  const handleUpdateKyc = () => {
    console.log('Redirecting to KYC update process');
    // Here you would typically navigate to KYC update page or handle the KYC process
    setShowKycModal(false);
    // navigate('/update-kyc'); // Example navigation
  };

  return (
    <div className="my-wins-container">
      {/* Background blur effect */}
      <div className="background-blur"></div>

      {/* Amount Won Card */}
      <div className="amount-won-card">
        <div className="amount-card-background">
          <svg className="pattern-svg" width="380" height="105" viewBox="0 0 380 105" fill="none">
            <path d="M20.132 1.61307C29.3697 -20.6887 42.9096 -40.9526 59.9787 -58.0216C77.0477 -75.0907 97.3116 -88.6305 119.613 -97.8682L189.957 71.957L20.132 1.61307Z" fill="#6522C6"/>
            <path d="M20.132 1.61307C29.3697 -20.6887 42.9096 -40.9526 59.9787 -58.0216C77.0477 -75.0907 97.3116 -88.6305 119.613 -97.8682L189.957 71.957L20.132 1.61307Z" fill="white" style={{mixBlendMode: 'color-burn'}}/>
            <path d="M20.2101 142.379C29.4478 164.681 42.9877 184.945 60.0568 202.014C77.1258 219.083 97.3897 232.623 119.692 241.86L190.035 72.0352L20.2101 142.379Z" fill="#6522C6"/>
            <path d="M20.2101 142.379C29.4478 164.681 42.9877 184.945 60.0568 202.014C77.1258 219.083 97.3897 232.623 119.692 241.86L190.035 72.0352L20.2101 142.379Z" fill="white" style={{mixBlendMode: 'color-burn'}}/>
            <path d="M260.301 241.782C282.603 232.544 302.867 219.004 319.936 201.935C337.005 184.866 350.545 164.602 359.782 142.301L189.957 71.9569L260.301 241.782Z" fill="#6522C6"/>
            <path d="M260.301 241.782C282.603 232.544 302.867 219.004 319.936 201.935C337.005 184.866 350.545 164.602 359.782 142.301L189.957 71.9569L260.301 241.782Z" fill="white" style={{mixBlendMode: 'color-burn'}}/>
            <path d="M260.301 -97.868C282.603 -88.6303 302.867 -75.0904 319.936 -58.0213C337.005 -40.9523 350.545 -20.6884 359.782 1.61339L189.957 71.9572L260.301 -97.868Z" fill="#6522C6"/>
            <path d="M260.301 -97.868C282.603 -88.6303 302.867 -75.0904 319.936 -58.0213C337.005 -40.9523 350.545 -20.6884 359.782 1.61339L189.957 71.9572L260.301 -97.868Z" fill="white" style={{mixBlendMode: 'color-burn'}}/>
          </svg>
        </div>
        <div className="amount-content">
          <div className="amount-label">Amount Won</div>
          <div className="amount-value">₹2500</div>
        </div>
        <img src="https://api.builder.io/api/v1/image/assets/TEMP/3de5387c05e303b8907f19c55759244719cddb80?width=758" alt="Coins blur" className="coins-blur" />
        <img src="https://api.builder.io/api/v1/image/assets/TEMP/f490255d073a77f7c549fe9c28991fda348807cb?width=176" alt="Coins" className="coins-image" />
      </div>

      {/* Main Content */}
      <div className="main-content">
        <div className="main-content-inner">
          {/* Tabs */}
          <div className="tabs-section">
            <div className="tabs-container">
              <button 
                className={`tab ${activeTab === 'active' ? 'active' : ''}`}
                onClick={() => setActiveTab('active')}
              >
                Active (2)
              </button>
              <button 
                className={`tab ${activeTab === 'past' ? 'active' : ''}`}
                onClick={() => setActiveTab('past')}
              >
                Past (2)
              </button>
            </div>
          </div>

          {/* Search and Controls */}
          <div className="search-section">
            <div className="search-input">
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M17.5005 17.5L13.8838 13.8833" stroke="#270659" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M9.16667 15.8333C12.8486 15.8333 15.8333 12.8486 15.8333 9.16667C15.8333 5.48477 12.8486 2.5 9.16667 2.5C5.48477 2.5 2.5 5.48477 2.5 9.16667C2.5 12.8486 5.48477 15.8333 9.16667 15.8333Z" stroke="#270659" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <input
                type="text"
                placeholder="Search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="control-buttons">
              <button className="filter-btn">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M3 6H21" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M7 12H17" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M10 18H14" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              <div className="view-toggle">
                <div className="view-btn active">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M9 3H4C3.44772 3 3 3.44772 3 4V9C3 9.55228 3.44772 10 4 10H9C9.55228 10 10 9.55228 10 9V4C10 3.44772 9.55228 3 9 3Z" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M20 3H15C14.4477 3 14 3.44772 14 4V9C14 9.55228 14.4477 10 15 10H20C20.5523 10 21 9.55228 21 9V4C21 3.44772 20.5523 3 20 3Z" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M20 14H15C14.4477 14 14 14.4477 14 15V20C14 20.5523 14.4477 21 15 21H20C20.5523 21 21 20.5523 21 20V15C21 14.4477 20.5523 14 20 14Z" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M9 14H4C3.44772 14 3 14.4477 3 15V20C3 20.5523 3.44772 21 4 21H9C9.55228 21 10 20.5523 10 20V15C10 14.4477 9.55228 14 9 14Z" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div className="view-btn">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M3 12H3.01" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 18H3.01" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M3 6H3.01" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8 12H21" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8 18H21" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M8 6H21" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>

          {/* Win Cards */}
          <div className="wins-list">
            {/* First Win Card - DAYWIN */}
            <div className="win-card" style={{margin: '0 auto'}}>
              <div className="card-background" style={{backgroundImage: 'url(https://cdn.builder.io/api/v1/image/assets%2F6116463ed266402f822d2635dd2eca30%2F48bd5193e97d4074b8050530fea7d944)', backgroundPosition: '50% 50%', backgroundSize: '100% 100%', backgroundRepeat: 'no-repeat'}}></div>
              
              <img src="https://api.builder.io/api/v1/image/assets/TEMP/d9f38b35558b9a9ec0f4a317ed5cb8c8cf8bf462?width=228" alt="DAYWIN" className="lottery-logo" />
              
              <div className="ticket-info">
                <div className="ticket-number">7206</div>
                <div className="ticket-label">Tickets No.</div>
              </div>

              <div className="prize-info">
                <div className="prize-row">
                  <span className="prize-label">Prize No</span>
                  <span className="prize-value">7th</span>
                </div>
                <div className="prize-row">
                  <span className="prize-label">Prize Money</span>
                  <span className="prize-value">₹200</span>
                </div>
                <div className="prize-row">
                  <span className="prize-label">Tickets</span>
                  <span className="prize-value">1</span>
                </div>
              </div>

              <div className="card-divider"></div>

              <div className="card-footer">
                <div className="draw-date">
                  <span className="date-label">Draw Date: </span>
                  <span className="date-value">30 July 2025</span>
                </div>
                <div className="status-badge">Initiated</div>
              </div>
            </div>

            {/* Second Win Card - MEGA 5 */}
            <div className="win-card mega5-card">
              <div className="card-background" style={{backgroundImage: 'url(https://cdn.builder.io/api/v1/image/assets%2F6116463ed266402f822d2635dd2eca30%2F48bd5193e97d4074b8050530fea7d944)', backgroundSize: '100% 100%', backgroundRepeat: 'no-repeat'}}></div>
              
              <img src="https://api.builder.io/api/v1/image/assets/TEMP/eb65266e7aad338778880a986beba130839698fa?width=218" alt="MEGA 5" className="lottery-logo mega5-logo" />
              
              <div className="ticket-info mega5-ticket">
                <div className="ticket-number">U088</div>
                <div className="ticket-label">Tickets No.</div>
              </div>

              <div className="prize-info mega5-prize">
                <div className="prize-row">
                  <span className="prize-label">Prize No</span>
                  <span className="prize-value">7th</span>
                </div>
                <div className="prize-row">
                  <span className="prize-label">Prize Money</span>
                  <span className="prize-value">₹200</span>
                </div>
                <div className="prize-row">
                  <span className="prize-label">Tickets</span>
                  <span className="prize-value">1</span>
                </div>
                <div className="prize-row">
                  <span className="prize-label">Claiming Time</span>
                  <span className="prize-value">30 days</span>
                </div>
              </div>

              <div className="card-divider"></div>

              <div className="card-footer mega5-footer">
                <div className="draw-date">
                  <span className="date-label">Draw Date: </span>
                  <span className="date-value">30 July 2025</span>
                </div>
              </div>

              <button className="claim-button" onClick={() => handleClaimPrize('U088')}>
                Claim Prize
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Phone Button */}
      <div className="floating-phone">
        <div className="phone-button">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M13.832 16.568C14.0385 16.6628 14.2712 16.6845 14.4917 16.6294C14.7122 16.5744 14.9073 16.4458 15.045 16.265L15.4 15.8C15.5863 15.5516 15.8279 15.35 16.1056 15.2111C16.3833 15.0723 16.6895 15 17 15H20C20.5304 15 21.0391 15.2107 21.4142 15.5858C21.7893 15.9609 22 16.4696 22 17V20C22 20.5304 21.7893 21.0391 21.4142 21.4142C21.0391 21.7893 20.5304 22 20 22C15.2261 22 10.6477 20.1036 7.27208 16.7279C3.89642 13.3523 2 8.7739 2 4C2 3.46957 2.21071 2.96086 2.58579 2.58579C2.96086 2.21071 3.46957 2 4 2H7C7.53043 2 8.03914 2.21071 8.41421 2.58579C8.78929 2.96086 9 3.46957 9 4V7C9 7.31049 8.92771 7.61672 8.78885 7.89443C8.65 8.17214 8.44839 8.41371 8.2 8.6L7.732 8.951C7.54842 9.09118 7.41902 9.29059 7.36579 9.51535C7.31256 9.74012 7.33878 9.97638 7.44 10.184C8.80668 12.9599 11.0544 15.2048 13.832 16.568Z" stroke="#270659" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>

      {/* KYC Update Modal */}
      {/* <UpdateKycModal
        isOpen={showKycModal}
        onClose={handleCloseKycModal}
        onUpdateKyc={handleUpdateKyc}
      /> */}
    </div>
  );
};

export default MyWins;
