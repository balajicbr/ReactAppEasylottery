import { useState, useEffect } from "react";
import { useSelector } from "react-redux"; // NEW
import "./Dashboard.css";
import { FaYoutube } from "react-icons/fa";
import axios from "axios";
import credit from "../assets/credit.png";
import ticket from "../assets/ticket.png";
import Refer from "../assets/Refer.jpg";
import Im_WinBg_ from "../assets/Im_WinBg_1.jpg";
import addCredits from "../assets/addCredits.png";

export default function Dashboard() {
  const user = useSelector((state) => state.auth.user.user);
  const firstName = user?.first_name;
  const refreshToken = user?.refreshToken;
  const [schemeDetails, setSchemeDetails] = useState(null);
  const [winningData, setWinningData] = useState(null);
  const [latestSchemeDetails, setLatestSchemeDetails] = useState([]);
  const [selectedScheme, setSelectedScheme] = useState("All");

  //Scheme Details
  useEffect(() => {
    const fetchSchemeDetails = async () => {
      try {
        const requestData = {
          refreshToken,
          formstep: "4",
          isd: "en",
          date: new Date().toISOString(),
        };

        const response = await axios.post(
          "https://api.easylotto.in/GetSchemeDetails",
          requestData,
        );

        setSchemeDetails(response.data);
      } catch (error) {
        console.error("Error fetching scheme details:", error);
      }
    };
    if (refreshToken) {
      fetchSchemeDetails();
    }
  }, [refreshToken]);
  const handleLiveResults = () => {
    window.open(
      "https://www.youtube.com/@EasyLotteryofficial/streams",
      "_blank",
    );
  };

  //winning Details
  useEffect(() => {
    const fetchWinningAmount = async () => {
      try {
        const requestData = {
          refreshToken,
          formstep: "getWinningAmount",
          id: "en",
        };

        const response = await axios.post(
          "https://api.easylotto.in/transaction",
          requestData,
        );
        setWinningData(response.data); // store it in state
      } catch (error) {
        console.error("Error fetching winning amount:", error);
      }
    };
    if (refreshToken) {
      fetchWinningAmount();
    }
  }, [refreshToken]);

  //Latest schemes
  useEffect(() => {
    const fetchLatestSchemes = async () => {
      try {
        const requestData = {
          refreshToken,
          formstep: "getfeaturedscheme",
        };

        const response = await axios.post(
          "https://api.easylotto.in/GetSchemeDetails",
          requestData,
        );

        setLatestSchemeDetails(response.data);
        // console.log("RESp",LatestSchemeDetails);
      } catch (error) {
        console.error("Error fetching schemes:", error);
      }
    };

    fetchLatestSchemes();
  }, [refreshToken]);

  // filter logic
  const filteredSchemes =
    selectedScheme === "All"
      ? schemeDetails
      : schemeDetails.filter(
          (item) => item.json.scheme_name === selectedScheme,
        );
  // console.log("Filtered scheme is",filteredSchemes);
  return (
    <div className="dashboard-container">
      {/* Background Gradient */}
      <div className="dashboard-bg-gradient">
        <svg
          width="412"
          height="494"
          viewBox="0 0 412 494"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g clipPath="url(#clip0_522_8165)">
            <g opacity="0.2" filter="url(#filter0_f_522_8165)">
              <ellipse
                cx="203.5"
                cy="211.5"
                rx="330.5"
                ry="419.5"
                fill="#CEB0FF"
              />
            </g>
            <g
              style={{ mixBlendMode: "darken" }}
              filter="url(#filter1_f_522_8165)"
            >
              <path
                d="M203.247 373C392.265 373 545.494 452.652 545.494 550.907C545.494 649.163 392.265 728.815 203.247 728.815C14.2292 728.815 -139 649.163 -139 550.907C-139 452.652 14.2294 373 203.247 373Z"
                fill="#D2BAFF"
              />
            </g>
            <path
              d="M544.267 550.907C544.267 605.807 600.45 743.836 525.263 776.471C465.884 802.244 266.899 776.471 183.493 776.471C108.457 776.471 -50.8991 786.395 -107.308 765.109C-192.995 732.775 -142.317 618.071 -140.227 550.907C-140.227 452.652 13.0019 373 202.02 373C391.038 373 544.267 452.652 544.267 550.907Z"
              fill="white"
            />
          </g>
          <defs>
            <filter
              id="filter0_f_522_8165"
              x="-357.7"
              y="-438.7"
              width="1122.4"
              height="1300.4"
              filterUnits="userSpaceOnUse"
              colorInterpolationFilters="sRGB"
            >
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend
                mode="normal"
                in="SourceGraphic"
                in2="BackgroundImageFix"
                result="shape"
              />
              <feGaussianBlur
                stdDeviation="115.35"
                result="effect1_foregroundBlur_522_8165"
              />
            </filter>
            <filter
              id="filter1_f_522_8165"
              x="-147.3"
              y="364.7"
              width="701.094"
              height="372.415"
              filterUnits="userSpaceOnUse"
              colorInterpolationFilters="sRGB"
            >
              <feFlood floodOpacity="0" result="BackgroundImageFix" />
              <feBlend
                mode="normal"
                in="SourceGraphic"
                in2="BackgroundImageFix"
                result="shape"
              />
              <feGaussianBlur
                stdDeviation="4.15"
                result="effect1_foregroundBlur_522_8165"
              />
            </filter>
            <clipPath id="clip0_522_8165">
              <rect
                width="412"
                height="587"
                fill="white"
                transform="translate(0 -93)"
              />
            </clipPath>
          </defs>
        </svg>
      </div>

      {/* Main Content */}
      <div className="dashboard-content">
        {/* User Greeting and Live Results */}
        <div className="greeting-section">
          <div className="greeting-content">
            <h1 className="greeting-text">Hi, {firstName}</h1>
            <button onClick={handleLiveResults} className="live-results-btn">
              <FaYoutube className="text-xl" color="#ffffff" />
              <span>View Live Results</span>
            </button>
          </div>
        </div>

        {/* Conditional divs based on schemeDetails[0].credit_visible */}
        {schemeDetails?.length > 0 && (
          <>
            {schemeDetails[0].json.credit_visible === 0 && (
              <div className="conditional-section">
                <img
                  src={addCredits}
                  alt="Add Credits"
                  className="w-full rounded-xl"
                />
              </div>
            )}
            {schemeDetails[0].json.credit_visible === 1 && (
              <div className="conditional-section">
                <img
                  src="https://easylottery.in/img/4/db02/BuyYourTicket.jpg"
                  alt="Buy Your Ticket"
                  className="w-full rounded-xl"
                />
              </div>
            )}
            {schemeDetails[0].json.credit_visible === 2 && (
              <div className="stats-section">
                <div className="stat-card">
                  <div className="stat-content">
                    <div className="stat-value">₹2500</div>
                    <div className="stat-label">Amount Won</div>
                  </div>
                  <div className="stat-icon">
                    <img src={credit} alt="Credit" />
                  </div>
                </div>
                <div className="stat-card">
                  <div className="stat-content">
                    <div className="stat-value">54</div>
                    <div className="stat-label">Active Tickets</div>
                  </div>
                  <div className="stat-icon">
                    <img src={ticket} alt="Ticket" />
                  </div>
                </div>
              </div>
            )}
          </>
        )}

        {/* Promotional Banner */}
        <div className="promo-banner">
          <div className="promo-content">
            <div className="promo-text">
              <h3>Use code 'Happy 10' to get credits.</h3>
              <button className="copy-code-btn">
                <span>Copy Code</span>
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M16.6641 6.66602H8.33073C7.41025 6.66602 6.66406 7.41221 6.66406 8.33268V16.666C6.66406 17.5865 7.41025 18.3327 8.33073 18.3327H16.6641C17.5845 18.3327 18.3307 17.5865 18.3307 16.666V8.33268C18.3307 7.41221 17.5845 6.66602 16.6641 6.66602Z"
                    stroke="#AD1E24"
                    strokeWidth="1.04167"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M3.33073 13.3327C2.41406 13.3327 1.66406 12.5827 1.66406 11.666V3.33268C1.66406 2.41602 2.41406 1.66602 3.33073 1.66602H11.6641C12.5807 1.66602 13.3307 2.41602 13.3307 3.33268"
                    stroke="#AD1E24"
                    strokeWidth="1.04167"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </div>
          <div className="promo-visual">
            <div className="happy10-card">
              <span className="happy10-text">Happy 10</span>
              <svg
                className="gift-icon"
                width="32"
                height="32"
                viewBox="0 0 34 33"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15.8323 32L1.03125 21.1233L18.1979 13.6221L32.9989 24.4988L15.8323 32Z"
                  fill="#0D0D0D"
                  stroke="#0D0D0D"
                  strokeWidth="0.106667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M32.965 24.4988L18.1641 13.622V7.1582L32.965 18.0349V24.4988Z"
                  fill="#FFCB45"
                  stroke="#0D0D0D"
                  strokeWidth="0.106667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M32.9635 18.0273V24.4991L15.7969 32.0003V25.5365L32.9635 18.0273Z"
                  fill="#FFF066"
                  stroke="#0D0D0D"
                  strokeWidth="0.106667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M18.1666 7.15027V13.622L1 21.1232V14.6515L18.1666 7.15027Z"
                  fill="#FFF066"
                  stroke="#0D0D0D"
                  strokeWidth="0.106667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M15.8323 31.9995L1.03125 21.1227V14.8105L15.8323 25.5357V31.9995Z"
                  fill="#FFCB45"
                  stroke="#0D0D0D"
                  strokeWidth="0.106667"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
          </div>
          <div className="promo-indicators">
            <div className="indicator active"></div>
            <div className="indicator"></div>
            <div className="indicator"></div>
          </div>
        </div>
        {/* Winning Announcement */}
        {winningData?.length > 0 && winningData[0]?.status === 1 && (
          <div
            className="winning-section"
            style={{
              backgroundImage: `url(${Im_WinBg_})`,
              backgroundSize: "contain",
              backgroundPosition: "center",
            }}
          >
            <div className="winning-content">
              {/* <div className="winning-text">You have Won</div> */}
              <div className="winning-amount">₹{winningData[0].win_amount}</div>
            </div>
          </div>
        )}
        {/* Lottery Tickets Section */}
        <div className="tickets-section">
          <div className="tickets-header">
            <h2>Try your Luck, Buy a Ticket</h2>

            <div className="tickets-tabs">
              <button
                key="all"
                className={`tab ${selectedScheme === "All" ? "active" : ""}`}
                onClick={() => setSelectedScheme("All")}
              >
                {" "}
                All
              </button>
              {latestSchemeDetails.map((scheme, index) => (
                <button
                  key={scheme.json.id || index}
                  onClick={() => setSelectedScheme(scheme.json.scheme_name)}
                  className={`tab ${selectedScheme === scheme.json.scheme_name ? "active" : ""}`}
                >
                  {scheme.json.scheme_name} ({scheme.json.count})
                </button>
              ))}
            </div>
          </div>
          <div className="tickets-grid">
            {filteredSchemes && filteredSchemes.length > 0 ? (
              filteredSchemes.map((scheme) => (
                <div key={scheme.id} className="ticket-card-dash">
                  <img
                    src={scheme.json.image_url}
                    alt="Lottery Ticket"
                    className="ticket-image"
                  />
                  <div className="ticket-prize-banner">
                    <span>{scheme.json.prize || "Prize Info"}</span>
                  </div>

                  <div className="ticket-actions">
                    <button className="prize-details-btn">Prize Details</button>
                    <button className="buy-now-btn">Buy Now</button>
                  </div>
                  <div className="ticket-draw-date">
                    <span>{scheme.json.draw_date}</span>
                    <svg
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g clipPath="url(#clip0_645_12103)">
                        <path
                          d="M9.9974 18.3337C14.5998 18.3337 18.3307 14.6027 18.3307 10.0003C18.3307 5.39795 14.5998 1.66699 9.9974 1.66699C5.39502 1.66699 1.66406 5.39795 1.66406 10.0003C1.66406 14.6027 5.39502 18.3337 9.9974 18.3337Z"
                          stroke="#270659"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M10 13.3333V10"
                          stroke="#270659"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M10 6.66699H10.0083"
                          stroke="#270659"
                          strokeWidth="1.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_645_12103">
                          <rect width="20" height="20" fill="white" />
                        </clipPath>
                      </defs>
                    </svg>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500">No schemes to show</p>
            )}
          </div>

          <button className="view-all-btn">
            <span>View All Tickets</span>
            <svg
              width="20"
              height="20"
              viewBox="0 0 21 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M4.67188 10H16.3385"
                stroke="#AD1E24"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M10.5 4.16602L16.3333 9.99935L10.5 15.8327"
                stroke="#AD1E24"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </div>

        {/* Refer Friends Section */}
        <div className="refer-section">
          <img src={Refer}></img>
        </div>
      </div>

      <button
        className="phone-btn phone-btn-right"
        onClick={() => (window.location.href = "tel:18002966868")}
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M13.832 16.568C14.0385 16.6628 14.2712 16.6845 14.4917 16.6294C14.7122 16.5744 14.9073 16.4458 15.045 16.265L15.4 15.8C15.5863 15.5516 15.8279 15.35 16.1056 15.2111C16.3833 15.0723 16.6895 15 17 15H20C20.5304 15 21.0391 15.2107 21.4142 15.5858C21.7893 15.9609 22 16.4696 22 17V20C22 20.5304 21.7893 21.0391 21.4142 21.4142C21.0391 21.7893 20.5304 22 20 22C15.2261 22 10.6477 20.1036 7.27208 16.7279C3.89642 13.3523 2 8.7739 2 4C2 3.46957 2.21071 2.96086 2.58579 2.58579C2.96086 2.21071 3.46957 2 4 2H7C7.53043 2 8.03914 2.21071 8.41421 2.58579C8.78929 2.96086 9 3.46957 9 4V7C9 7.31049 8.92771 7.61672 8.78885 7.89443C8.65 8.17214 8.44839 8.41371 8.2 8.6L7.732 8.951C7.54842 9.09118 7.41902 9.29059 7.36579 9.51535C7.31256 9.74012 7.33878 9.97638 7.44 10.184C8.80668 12.9599 11.0544 15.2048 13.832 16.568Z"
            stroke="#181823"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </button>

      {/* Bottom Navigation */}
      {/* <div className="bottom-nav">
        <div className="bottom-nav-content">
          <button className="nav-item active">
            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M2.69995 8.8342C2.69989 8.59176 2.75273 8.35222 2.85477 8.1323C2.95682 7.91238 3.10562 7.71737 3.29078 7.56087L9.12412 2.5617C9.42494 2.30746 9.80608 2.16797 10.2 2.16797C10.5938 2.16797 10.975 2.30746 11.2758 2.5617L17.1091 7.56087C17.2943 7.71737 17.4431 7.91238 17.5451 8.1323C17.6472 8.35222 17.7 8.59176 17.7 8.8342V16.3342C17.7 16.7762 17.5244 17.2002 17.2118 17.5127C16.8992 17.8253 16.4753 18.0009 16.0333 18.0009H4.36662C3.92459 18.0009 3.50067 17.8253 3.18811 17.5127C2.87555 17.2002 2.69995 16.7762 2.69995 16.3342V8.8342Z" fill="#6A538D"/>
              <path d="M12.7 18V11.3333C12.7 11.1123 12.6122 10.9004 12.4559 10.7441C12.2996 10.5878 12.0876 10.5 11.8666 10.5H8.53328C8.31227 10.5 8.10031 10.5878 7.94403 10.7441C7.78775 10.9004 7.69995 11.1123 7.69995 11.3333V18" fill="white"/>
            </svg>
            <span>Dashboard</span>
          </button>
          
          <button className="nav-item">
            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M17.264 5.5H3.9307C3.01023 5.5 2.26404 6.24619 2.26404 7.16667V13.8333C2.26404 14.7538 3.01023 15.5 3.9307 15.5H17.264C18.1845 15.5 18.9307 14.7538 18.9307 13.8333V7.16667C18.9307 6.24619 18.1845 5.5 17.264 5.5Z" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M10.6026 12.1654C11.5231 12.1654 12.2692 11.4192 12.2692 10.4987C12.2692 9.57822 11.5231 8.83203 10.6026 8.83203C9.68211 8.83203 8.93591 9.57822 8.93591 10.4987C8.93591 11.4192 9.68211 12.1654 10.6026 12.1654Z" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M5.59998 10.5H5.60831M15.6 10.5H15.6083" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span>Credit</span>
          </button>
          
          <button className="nav-item buy-ticket">
            <div className="buy-ticket-icon">
              <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M1.80334 7.49947C2.46639 7.49947 3.10227 7.76286 3.57111 8.2317C4.03995 8.70054 4.30334 9.33643 4.30334 9.99947C4.30334 10.6625 4.03995 11.2984 3.57111 11.7672C3.10227 12.2361 2.46639 12.4995 1.80334 12.4995V14.1661C1.80334 14.6082 1.97894 15.0321 2.2915 15.3446C2.60406 15.6572 3.02798 15.8328 3.47001 15.8328H16.8033C17.2454 15.8328 17.6693 15.6572 17.9819 15.3446C18.2944 15.0321 18.47 14.6082 18.47 14.1661V12.4995C17.807 12.4995 17.1711 12.2361 16.7022 11.7672C16.2334 11.2984 15.97 10.6625 15.97 9.99947C15.97 9.33643 16.2334 8.70054 16.7022 8.2317C17.1711 7.76286 17.807 7.49947 18.47 7.49947V5.8328C18.47 5.39078 18.2944 4.96685 17.9819 4.65429C17.6693 4.34173 17.2454 4.16614 16.8033 4.16614H3.47001C3.02798 4.16614 2.60406 4.34173 2.2915 4.65429C1.97894 4.96685 1.80334 5.39078 1.80334 5.8328V7.49947Z" stroke="url(#paint0_linear_ticket_nav)" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M7.64001 10.0008L9.30668 11.6674L12.64 8.33411" stroke="url(#paint1_linear_ticket_nav)" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
                <defs>
                  <linearGradient id="paint0_linear_ticket_nav" x1="1.80334" y1="6.69101" x2="20.5416" y2="9.15633" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#FFB940"/>
                    <stop offset="1" stopColor="#FF8400"/>
                  </linearGradient>
                  <linearGradient id="paint1_linear_ticket_nav" x1="7.64001" y1="9.0555" x2="13.2517" y2="9.83072" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#FFB940"/>
                    <stop offset="1" stopColor="#FF8400"/>
                  </linearGradient>
                </defs>
              </svg>
            </div>
            <span>Buy Ticket</span>
          </button>
          
          <button className="nav-item">
            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M4.1499 7.16747L12.9666 2.9508C13.0665 2.90297 13.175 2.87554 13.2857 2.87013C13.3964 2.86473 13.507 2.88145 13.6111 2.91931C13.7153 2.95718 13.8108 3.01543 13.8921 3.09067C13.9735 3.1659 14.039 3.25661 14.0849 3.35747L15.8166 7.16747" stroke="#6A538D" strokeWidth="1.04" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M5.3999 8.83268V7.16602" stroke="#6A538D" strokeWidth="1.04" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M5.3999 12.166V12.9993" stroke="#6A538D" strokeWidth="1.04" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M5.3999 16.334V18.0007" stroke="#6A538D" strokeWidth="1.04" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M17.0667 7.16602H3.73332C2.81284 7.16602 2.06665 7.91221 2.06665 8.83268V16.3327C2.06665 17.2532 2.81284 17.9993 3.73332 17.9993H17.0667C17.9871 17.9993 18.7333 17.2532 18.7333 16.3327V8.83268C18.7333 7.91221 17.9871 7.16602 17.0667 7.16602Z" stroke="#6A538D" strokeWidth="1.04" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span>My Tickets</span>
          </button>
          
          <button className="nav-item">
            <svg width="20" height="20" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="10.7974" cy="10.5013" r="0.833333" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="16.6334" cy="10.4993" r="0.833333" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="4.96932" cy="10.5013" r="0.833333" stroke="#6A538D" strokeWidth="1.04167" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span>More</span>
          </button>
        </div>
        
        <div className="nav-highlight">
          <svg width="331" height="17" viewBox="0 0 331 17" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M166.503 0.0153809C183.6 0.286758 197.815 4.01702 212.735 7.8855C236.218 13.974 248.171 15.3699 256.109 15.3699C262.512 15.3699 308.115 15.7032 330.113 15.8699L330.105 16.8699C308.104 16.7032 262.507 16.3699 256.109 16.3699C248.048 16.3699 236.001 14.9518 212.483 8.85425C197.06 4.85527 182.514 1.04025 164.794 1.00073C147.31 1.11305 132.898 4.89457 117.626 8.85425C94.1087 14.9518 82.0613 16.3699 74 16.3699C67.6025 16.3699 22.0057 16.7032 0.00390625 16.8699L-0.00390625 15.8699C21.9943 15.7032 67.5975 15.3699 74 15.3699C81.9387 15.3699 93.8916 13.974 117.374 7.8855C132.294 4.01709 146.509 0.286885 163.605 0.0153809V0.000732422H166.504L166.503 0.0153809Z" fill="url(#paint0_linear_nav_highlight)"/>
            <defs>
              <linearGradient id="paint0_linear_nav_highlight" x1="330.113" y1="0.000732422" x2="-0.00390625" y2="0.000732422" gradientUnits="userSpaceOnUse">
                <stop stopColor="#FF9211" stopOpacity="0.08"/>
                <stop offset="0.496572" stopColor="#FF9211"/>
                <stop offset="1" stopColor="#FF9211" stopOpacity="0.08"/>
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div> */}
    </div>
  );
}
