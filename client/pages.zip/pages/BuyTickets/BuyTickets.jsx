import React, { useState, useEffect } from "react";
import "./BuyTickets.css";
import big50Banner from "../../assets/Bn_BuyTicket.jpg";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import axios from "axios";
import PrizeDetails from "../../comp/PrizeDetails/PrizeDetails";
import AlertPopup from "../../comp/AlertPopup/AlertPopup";
import PurchaseConfirmation from "../../comp/PurchaseConfirmation/PurchaseConfirmation";
import { IoCompassOutline } from "react-icons/io5";

const BuyTickets = () => {
  const [activeTab, setActiveTab] = useState("random");
  const [mode, setMode] = useState("single");

  const [randomQuantity, setRandomQuantity] = useState("");
  const [randomTotalAmount, setRandomTotalAmount] = useState(0);

  const [luckyQuantity, setLuckyQuantity] = useState("");
  const [luckyTotalAmount, setLuckyTotalAmount] = useState(0);

  const [customQuantity, setCustomQuantity] = useState("");
  const [customTotalAmount, setCustomTotalAmount] = useState(0);

  const [singleQuantity, setSingleQuantity] = useState("");
  const [singleTotalAmount, setSingleTotalAmount] = useState(0);
  const [multipleTotalAmount, setMultipleTotalAmount] = useState(0);

  const [count, setCount] = useState("");
  const [numbers, setNumbers] = useState([]);
  const [showPrizes, setShowPrizes] = useState(false);

  const location = useLocation();
  const { id } = location.state || {};
  const [schemes, setSchemes] = useState([]);
  const [selectedId, setSelectedId] = useState(id || "");
  const user = useSelector((state) => state.auth.user.user);
  const refreshToken = user?.refreshToken;
  const [selectedScheme, setSelectedScheme] = useState(null);

  const [alertMessage, setAlertMessage] = useState("");
  const [showAlert, setShowAlert] = useState(false);

  const [alphanumFields, setAlphanumFields] = useState([]);
  const [numFields, setNumFields] = useState([]);
  const [singleNumber, setSingleNumber] = useState("");
  const [showPurchaseConfirm, setShowPurchaseConfirm] = useState(false);
  const [purchaseType, setPurchaseType] = useState("");

  useEffect(() => {
    const fetchSchemeDetails = async () => {
      if (!refreshToken || !selectedId) return;

      try {
        const requestData = {
          refreshToken,
          formstep: "getSchemeDetails",
          id: selectedId,
          isd: "en",
          scheme: selectedId,
        };
        const response = await axios.post(
          "https://api.easylotto.in/easyshoping",
          requestData,
          { headers: { "lang-policies-mode": "max-age=0" } },
        );
        setSelectedScheme(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchSchemeDetails();
  }, [selectedId, refreshToken]);

  useEffect(() => {
    const fetchSchemes = async () => {
      if (!refreshToken) return;

      try {
        const requestData = { refreshToken, formstep: "getSchemesData" };
        const response = await axios.post(
          "https://api.easylotto.in/GetSchemeDetails",
          requestData,
        );
        setSchemes(response.data || []);
      } catch (error) {
        console.error(error);
      }
    };
    fetchSchemes();
  }, [refreshToken]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    const qty = parseInt(randomQuantity, 10) || 0;
    setRandomTotalAmount(tAmount * qty);
  }, [randomQuantity, selectedScheme]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    const qty = parseInt(luckyQuantity, 10) || 0;
    setLuckyTotalAmount(tAmount * qty);
  }, [luckyQuantity, selectedScheme]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    const qty = parseInt(customQuantity, 10) || 0;
    setCustomTotalAmount(tAmount * qty);
  }, [customQuantity, selectedScheme]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    const qty = parseInt(luckyQuantity, 10) || 0;
    setLuckyTotalAmount(tAmount * qty);
  }, [luckyQuantity, selectedScheme]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    const qty = parseInt(singleQuantity, 10) || 0;
    setSingleTotalAmount(tAmount * qty);
  }, [singleQuantity, selectedScheme]);

  useEffect(() => {
    const tAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) || 0;
    setMultipleTotalAmount(tAmount * numbers.length);
  }, [numbers, selectedScheme]);

  useEffect(() => {
    const alpLen = parseInt(selectedScheme?.[0]?.json?.alp_len, 10) || 0;
    const numLen = parseInt(selectedScheme?.[0]?.json?.length, 10) || 0;
    setAlphanumFields(Array(alpLen).fill(""));
    setNumFields(Array(numLen).fill(""));
  }, [selectedScheme]);

  const resetAllFields = () => {
    setRandomQuantity("");
    setLuckyQuantity("");
    setCustomQuantity("");
    setSingleQuantity("");
    setCount("");
    setNumbers([]);
    setAlphanumFields(
      Array(parseInt(selectedScheme?.[0]?.json?.alp_len || 0)).fill(""),
    );
    setNumFields(
      Array(parseInt(selectedScheme?.[0]?.json?.length || 0)).fill(""),
    );
    setSingleNumber("");
  };

  const handleSingleFieldChange = (index, value, isAlp) => {
    const targetArray = isAlp ? [...alphanumFields] : [...numFields];
    targetArray[index] = value;
    if (isAlp) setAlphanumFields(targetArray);
    else setNumFields(targetArray);

    const combinedNumber = [...targetArray].join("");
    const otherArray = isAlp ? numFields : alphanumFields;
    setSingleNumber(
      isAlp
        ? [...targetArray, ...otherArray].join("")
        : [...alphanumFields, ...targetArray].join(""),
    );
  };

  const handleAddNumber = () => {
    if (singleNumber.trim()) {
      setNumbers([...numbers, singleNumber]);
      setAlphanumFields(Array(alphanumFields.length).fill(""));
      setNumFields(Array(numFields.length).fill(""));
      setSingleNumber("");
    }
  };

  const handleRemoveNumber = (index) => {
    const updated = [...numbers];
    updated.splice(index, 1);
    setNumbers(updated);
  };
  //Random Buy now
  const handleRandomBuy = () => {
    const maxTicket = parseInt(selectedScheme?.[0]?.json?.maxticket, 10) || 0;
    const remainTicket =
      parseInt(selectedScheme?.[0]?.json?.remaingticket, 10) || 0;
    const maxDrawTicket =
      parseInt(selectedScheme?.[0]?.json?.maxdrawticket, 10) || 0;
    const availableCount = parseInt(selectedScheme?.[0]?.json?.count, 10) || 0;
    const credits = parseInt(selectedScheme?.[0]?.json?.creadits, 10) || 0;

    const qty = parseInt(randomQuantity, 10) || 0;
    const totalAmount = parseInt(selectedScheme?.[0]?.json?.t_amount, 10) * qty;

    if (qty <= 0) {
      setAlertMessage("Enter quantity of tickets.");
      setShowAlert(true);
      return;
    }

    if (qty > maxTicket) {
      setAlertMessage(`Maximum of ${maxTicket} tickets per transaction.`);
      setShowAlert(true);
      return;
    }

    if (qty > remainTicket) {
      setAlertMessage(`Maximum ${maxDrawTicket} tickets per draw.`);
      setShowAlert(true);
      return;
    }

    if (qty > availableCount) {
      setAlertMessage(
        "These many tickets are not available. Please reduce the quantity.",
      );
      setShowAlert(true);
      return;
    }

    // if (totalAmount > credits) {
    //   setAlertMessage("Insufficient credits to buy tickets.");
    //   setShowAlert(true);
    //   return;
    // }

    console.log("Proceed to buy", qty, totalAmount);
    setPurchaseType("random");
    setShowPurchaseConfirm(true);
  };

  //Lucky number buy now
  const handleLuckyBuy = () => {
    const maxTicket = parseInt(selectedScheme?.[0]?.json?.maxticket, 10) || 0;
    const remainTicket =
      parseInt(selectedScheme?.[0]?.json?.remaingticket, 10) || 0;
    const maxDrawTicket =
      parseInt(selectedScheme?.[0]?.json?.maxdrawticket, 10) || 0;
    const availableCount = parseInt(selectedScheme?.[0]?.json?.count, 10) || 0;

    const qty = parseInt(luckyQuantity, 10) || 0;

    if (qty <= 0) {
      setAlertMessage("Enter quantity of tickets.");
      setShowAlert(true);
      return;
    }

    if (qty > maxTicket) {
      setAlertMessage(`Maximum of ${maxTicket} tickets per transaction.`);
      setShowAlert(true);
      return;
    }

    if (qty > remainTicket) {
      setAlertMessage(`Maximum ${maxDrawTicket} tickets per draw.`);
      setShowAlert(true);
      return;
    }

    if (qty > availableCount) {
      setAlertMessage(
        "These many tickets are not available. Please reduce the quantity.",
      );
      setShowAlert(true);
      return;
    }

    console.log("Proceed to lucky buy", qty, luckyTotalAmount);
    setPurchaseType("luckyNum");
    setShowPurchaseConfirm(true);
  };

  //Custom Single Buy
  const handleCustomSingleBuy = () => {
    const maxTicket = parseInt(selectedScheme?.[0]?.json?.maxticket, 10) || 0;
    const remainTicket =
      parseInt(selectedScheme?.[0]?.json?.remaingticket, 10) || 0;
    const maxDrawTicket =
      parseInt(selectedScheme?.[0]?.json?.maxdrawticket, 10) || 0;
    const availableCount = parseInt(selectedScheme?.[0]?.json?.count, 10) || 0;

    const qty = parseInt(singleQuantity, 10) || 0;

    if (qty <= 0) {
      setAlertMessage("Enter quantity of tickets.");
      setShowAlert(true);
      return;
    }

    if (!singleNumber.trim()) {
      setAlertMessage("Please select a number.");
      setShowAlert(true);
      return;
    }

    if (qty > maxTicket) {
      setAlertMessage(`Maximum of ${maxTicket} tickets per transaction.`);
      setShowAlert(true);
      return;
    }

    if (qty > remainTicket) {
      setAlertMessage(`Maximum ${maxDrawTicket} tickets per draw.`);
      setShowAlert(true);
      return;
    }

    if (qty > availableCount) {
      setAlertMessage(
        "These many tickets are not available. Please reduce the quantity.",
      );
      setShowAlert(true);
      return;
    }

    setPurchaseType("customSingle");
    setShowPurchaseConfirm(true);
  };

  //Custom Multiple buy

  const handleCustomMultipleBuy = () => {
    const maxTicket = parseInt(selectedScheme?.[0]?.json?.maxticket, 10) || 0;
    const remainTicket =
      parseInt(selectedScheme?.[0]?.json?.remaingticket, 10) || 0;
    const maxDrawTicket =
      parseInt(selectedScheme?.[0]?.json?.maxdrawticket, 10) || 0;
    const availableCount = parseInt(selectedScheme?.[0]?.json?.count, 10) || 0;

    const qty = numbers.length;

    console.log(
      "Multiple buy total amount and quantity are",
      multipleTotalAmount,
      qty,
    );

    if (qty <= 0) {
      setAlertMessage("Please add at least one number.");
      setShowAlert(true);
      return;
    }

    if (qty > maxTicket) {
      setAlertMessage(`Maximum of ${maxTicket} tickets per transaction.`);
      setShowAlert(true);
      return;
    }

    if (qty > remainTicket) {
      setAlertMessage(`Maximum ${maxDrawTicket} tickets per draw.`);
      setShowAlert(true);
      return;
    }

    if (qty > availableCount) {
      setAlertMessage(
        "These many tickets are not available. Please reduce the quantity.",
      );
      setShowAlert(true);
      return;
    }

    setPurchaseType("customMultiple");
    setShowPurchaseConfirm(true);
  };

  return (
    <div className="buyTickets">
      <div className="banner">
        {selectedScheme && selectedScheme[0] && (
          <div className="bannerWrapper">
            <img src={big50Banner} alt="Scheme Banner" className="bannerBg" />
            <div className="schemeNameBox">{selectedScheme[0].json.sname}</div>
            <div className="bannerPrize">
              First Prize : ₹{selectedScheme[0].json.amountt}
            </div>
            <div className="drawDate">
              Draw Date : {selectedScheme[0].json.draw_date}
            </div>
            <div className="actionButtons">
              <button className="Termsbtn">Terms & Conditions</button>
              <button
                className="viewprizeBtn"
                onClick={() => setShowPrizes(true)}
              >
                Prize Details
              </button>
            </div>
          </div>
        )}
      </div>

      <p className="infoText">
        Please choose one of the methods to buy a ticket
      </p>
      <div className="schemeDropdown">
        <label>Scheme</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value)}
        >
          {schemes.map((scheme) => (
            <option key={scheme.json.id} value={scheme.json.id}>
              {scheme.json.name}
            </option>
          ))}
        </select>
      </div>
      <div className="tabs">
        <button
          className={activeTab === "random" ? "active" : ""}
          onClick={() => {
            resetAllFields();
            setActiveTab("random");
          }}
        >
          Random / Lucky Digits
        </button>
        <button
          className={activeTab === "choose" ? "active" : ""}
          onClick={() => {
            resetAllFields();
            setActiveTab("choose");
          }}
        >
          Choose Your Numbers
        </button>
      </div>
      {activeTab === "random" && (
        <div className="randomTab">
          <div className="card">
            <h4>Random Tickets</h4>
            <p className="subtext">Purchase a random set of ticket</p>

            <label>Quantity</label>
            <input
              className="quantity"
              type="text"
              value={randomQuantity}
              // onChange={(e) => setRandomQuantity(e.target.value)}
              onChange={(e) => {
                const numericValue = e.target.value.replace(/[^\d]/g, "");
                setRandomQuantity(numericValue);
              }}
              placeholder="Enter quantity"
            />
            <div className="bottomRow">
              <div>
                <p className="small">Total</p>
                <p className="amount">₹{randomTotalAmount}</p>
              </div>
              <button
                className="buyBtn"
                onClick={handleRandomBuy}
                disabled={!randomQuantity}
              >
                Buy Now
              </button>
            </div>
          </div>
          <div className="card">
            <h4>Choose Your Own Number</h4>
            <p className="subtext">Number position based ticket search</p>

            <label>Enter total no. of count</label>
            <select value={count} onChange={(e) => setCount(e.target.value)}>
              <option value="">0</option>
              {[...Array(9)].map((_, i) => (
                <option key={i + 1}>{i + 1}</option>
              ))}
            </select>

            <label>Quantity</label>
            <input
              className="quantity"
              type="text"
              value={luckyQuantity}
              // onChange={(e) => setLuckyQuantity(e.target.value)}
              onChange={(e) => {
                const numericValue = e.target.value.replace(/[^\d]/g, "");
                setLuckyQuantity(numericValue);
              }}
              placeholder="Enter quantity"
            />

            <div className="bottomRow">
              <div>
                <p className="small">Total</p>
                <p className="amount">₹{luckyTotalAmount}</p>
              </div>
              <button
                className="buyBtn"
                disabled={!count}
                onClick={handleLuckyBuy}
              >
                Buy Now
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === "choose" && (
        <div className="chooseTab">
          <div className="mode">
            <label>
              <input
                type="radio"
                name="mode"
                value="single"
                checked={mode === "single"}
                onChange={(e) => {
                  resetAllFields();
                  setMode(e.target.value);
                }}
              />
              Single
            </label>
            <label>
              <input
                type="radio"
                name="mode"
                value="multiple"
                checked={mode === "multiple"}
                onChange={(e) => {
                  resetAllFields();
                  setMode(e.target.value);
                }}
              />
              Multiple
            </label>
          </div>

          {mode === "single" && (
            <div className="card">
              <h4>Choose Your Number</h4>

              <div className="numberInputs">
                {alphanumFields.map((val, i) => (
                  <select
                    key={`alp-${i}`}
                    value={val}
                    onChange={(e) =>
                      handleSingleFieldChange(i, e.target.value, true)
                    }
                  >
                    <option value="">A</option>
                    {selectedScheme?.[0]?.json?.alpha_series.map(
                      (alphaOption, idx) => (
                        <option key={idx} value={alphaOption}>
                          {alphaOption}
                        </option>
                      ),
                    )}
                  </select>
                ))}

                {numFields.map((val, i) => (
                  <select
                    key={`num-${i}`}
                    value={val}
                    onChange={(e) =>
                      handleSingleFieldChange(i, e.target.value, false)
                    }
                  >
                    <option value="">0</option>
                    {[...Array(10)].map((_, idx) => (
                      <option key={idx} value={idx}>
                        {idx}
                      </option>
                    ))}
                    <option value="_">*</option>
                  </select>
                ))}
              </div>
              <label>Quantity</label>
              <input
                className="quantity"
                type="text"
                value={singleQuantity}
                onChange={(e) => {
                  const numericValue = e.target.value.replace(/[^\d]/g, "");
                  setSingleQuantity(numericValue);
                }}
                placeholder="Enter quantity"
              />
              <div className="bottomRow">
                <div>
                  <p className="small">Total</p>
                  <p className="amount">₹{singleTotalAmount}</p>
                </div>
                <button className="buyBtn" onClick={handleCustomSingleBuy}>
                  Buy Now
                </button>
              </div>
            </div>
          )}

          {mode === "multiple" && (
            <div className="card">
              <h4>Choose Multiple Numbers</h4>

              <div className="numberInputs">
                {alphanumFields.map((val, i) => (
                  <select
                    key={`alp-${i}`}
                    value={val}
                    onChange={(e) =>
                      handleSingleFieldChange(i, e.target.value, true)
                    }
                  >
                    <option value="">A</option>
                    {selectedScheme?.[0]?.json?.alpha_series.map(
                      (alphaOption, idx) => (
                        <option key={idx} value={alphaOption}>
                          {alphaOption}
                        </option>
                      ),
                    )}
                  </select>
                ))}

                {numFields.map((val, i) => (
                  <select
                    key={`num-${i}`}
                    value={val}
                    onChange={(e) =>
                      handleSingleFieldChange(i, e.target.value, false)
                    }
                  >
                    <option value="">0</option>
                    {[...Array(10)].map((_, idx) => (
                      <option key={idx} value={idx}>
                        {idx}
                      </option>
                    ))}
                    <option value="_">*</option>
                  </select>
                ))}
              </div>

              <button className="addBtn" onClick={handleAddNumber}>
                + Add
              </button>

              {numbers.length > 0 && (
                <div className="numbersWrap">
                  <label>Numbers</label>
                  <div className="chipContainer">
                    {numbers.map((num, idx) => (
                      <div className="chip" key={idx}>
                        {num}
                        <span
                          className="removeChip"
                          onClick={() => handleRemoveNumber(idx)}
                        >
                          ×
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="bottomRow">
                <div>
                  <p className="small">Total</p>
                  <p className="amount">₹{multipleTotalAmount}</p>
                </div>
                <button className="buyBtn" onClick={handleCustomMultipleBuy}>
                  Buy Now
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {showPrizes && (
        <PrizeDetails
          selectedId={selectedId}
          refreshToken={refreshToken}
          onClose={() => setShowPrizes(false)}
        />
      )}

      {showAlert && (
        <AlertPopup
          message={alertMessage}
          onClose={() => setShowAlert(false)}
        />
      )}

      {/* {showPurchaseConfirm && (
  <PurchaseConfirmation
    type={purchaseType}
    id={selectedId}
    count={count}
    totalAmount={
      purchaseType === "random"
        ? randomTotalAmount
        : purchaseType === "luckyNum"
        ? luckyTotalAmount
        : purchaseType === "customSingle"
        ? singleTotalAmount
        : multipleTotalAmount
    }
    randomQuantity={
      purchaseType === "random"
        ? randomQuantity
        : purchaseType === "luckyNum"
        ? luckyQuantity
        : purchaseType === "customSingle"
        ? 1
        : numbers.length
    }
    onClose={() => setShowPurchaseConfirm(false)}
  />
)} */}

      {showPurchaseConfirm && (
        <PurchaseConfirmation
          type={purchaseType}
          id={selectedId}
          count={count}
          totalAmount={
            purchaseType === "random"
              ? randomTotalAmount
              : purchaseType === "luckyNum"
                ? luckyTotalAmount
                : purchaseType === "customSingle"
                  ? singleTotalAmount
                  : multipleTotalAmount
          }
          randomQuantity={
            purchaseType === "random"
              ? randomQuantity
              : purchaseType === "luckyNum"
                ? luckyQuantity
                : purchaseType === "customSingle"
                  ? 1
                  : numbers.length
          }
          selectedNumber={
            purchaseType === "customSingle"
              ? singleNumber
              : purchaseType === "customMultiple"
                ? numbers.join(",")
                : ""
          }
          ticketLength={
            selectedScheme
              ? parseInt(selectedScheme[0].json.alp_len, 10) +
                parseInt(selectedScheme[0].json.length, 10)
              : 0
          }
          refreshToken={refreshToken}
          onClose={() => setShowPurchaseConfirm(false)}
        />
      )}
    </div>
  );
};

export default BuyTickets;
